/*
Alexsander & Welder
 */
package agenda;



    public class Main {
	private static Login tela;

	public static void main(String args[]){
		tela = new Login();
	}
}
    

